function openNav() {
    document.getElementById("mySidebar").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.getElementById("menuButton").innerHTML =
      "<i class='bx bx-x large-icon'></i>"; // Change icon to close
  }
  
  function closeNav() {
    document.getElementById("mySidebar").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
    document.getElementById("menuButton").innerHTML =
      "<i class='bx bx-menu large-icon'></i>"; // Change icon to open
  }
  
  function toggleNav() {
    if (document.getElementById("mySidebar").style.width === "250px") {
      closeNav();
    } else {
      openNav();
    }
  }
  